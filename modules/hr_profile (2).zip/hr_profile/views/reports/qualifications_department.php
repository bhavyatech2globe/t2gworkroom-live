<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div class="relative qualifications_department">
   <div id="qualifications_department" class="reports" ></div>
</div>