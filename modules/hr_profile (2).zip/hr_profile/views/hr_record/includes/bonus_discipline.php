 <div class="col-md-12"><h4><?php echo _l('bonus'); ?></h4><hr></div>

 <table class="table table-general_bonus scroll-responsive">
 	<thead>
 		<tr>
 			<th><?php echo _l('name_bonus'); ?></th>
 			<th><?php echo _l('hr_criteria'); ?></th>
 			<th><?php echo _l('time'); ?></th>
 			<th><?php echo _l('forms'); ?></th>
 			<th><?php echo _l('value_'); ?></th>                                             
 		</tr>
 	</thead>
 	<tbody></tbody>
 	<tfoot>
 		<td></td>
 		<td></td>
 		<td></td>
 		<td></td>                                  
 	</tfoot>
 </table>
 <div class="col-md-12"><h4><?php echo _l('discipline'); ?></h4><hr></div>

 <table class="table table-general_discipline scroll-responsive">
 	<thead>
 		<tr>
 			<th><?php echo _l('name_discipline'); ?></th>
 			<th><?php echo _l('hr_criteria'); ?></th>
 			<th><?php echo _l('time'); ?></th>
 			<th><?php echo _l('forms'); ?></th>                                     
 			<th><?php echo _l('value_'); ?></th>                                             
 		</tr>
 	</thead>
 	<tbody></tbody>
 	<tfoot>
 		<td></td>
 		<td></td>
 		<td></td>
 		<td></td>                                  
 	</tfoot>
 </table>